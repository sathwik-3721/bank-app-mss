//model file 
import { poolPromise } from "../utils/dbConnection.js";
const tableName = '' //table name
class Test {
    static async create() {
        try {
            //Your Query
            return ;
        } catch (err) {
            throw err;
        }
    }

    static async read() {
        try {
            //Your Query
            return ;
        } catch (err) {
            throw err;
        }
    }

    static async update() {
        try {
            //Your Query
            return ;
        } catch (err) {
            throw err;
        }
    }

    static async delete() {
        try {
            //Your Query
            return ;
        } catch (err) {
            throw err;
        }
    }

    static async getCustomers() {
        try {
            const pool = await poolPromise;
            const sql = 'SELECT * FROM Customers';
            const [res] = await pool.query(sql);
            console.log(res);
            return res;
        } catch(err) {
            throw err;
        }
    }

    static async validateCustomer(mobile_num, email, pancard_num) {
        try {   
            const pool = await poolPromise;
            const sql = 'SELECT mobile_num, email, pancard_num FROM Customers';
            const [res] = await pool.query(sql, [mobile_num, email, pancard_num]);
            console.log(res);
            return res;
        } catch(err) {
            throw err;
        }
    }

    static async createCustomer(first_name, last_name, mobile_num, email, pancard_num, dob, account_type) {
        try {
            const pool = await poolPromise;
            const validateCustomerResult = await Test.validateCustomer(mobile_num, email, pancard_num);
            console.log(validateCustomerResult);
            if (validateCustomerResult.length != 0) {
                return false;
            } else {
                const sql = 'INSERT INTO Customers (first_name, last_name, mobile_num, email, pancard_num, dob, account_type) VALUES (?, ?, ?, ?, ?, ?, ?)';
                const [res] = await pool.query(sql, [first_name, last_name, mobile_num, email, pancard_num, dob, account_type]);
                console.log(res);
                return res;
            }
        } catch(err) {
            throw err;
        }
    }

    static async validateAccount(customer_id) {
        try {
            const pool = await poolPromise;
            const sql = 'SELECT account_number FROM Accounts WHERE customer_id = ?';
            const [res] = await pool.query(sql, [customer_id]);
            console.log("res", res);
            if (res.length == 0) {
                console.log("if");
                return false;
            } else {
                return true;
            }
        } catch(err) {
            throw err;
        }
    }

    static async createAccountNumber(customer_id) {
        try {
            console.log("in createAccountNumber");
            const pool = await poolPromise;
            console.log("after pool in createAccountNUmber");
            const sql = 'SELECT mobile_num, pancard_num FROM Customers WHERE customer_id = ?';
            const [res] = await pool.query(sql, [customer_id]);
            console.log("mob", res);
            if (res.length != 0) {
                let mobileNum = res[0].mobile_num;
                let pancardNum = res[0].pancard_num;
                let accountNumber = mobileNum.substring(0, 5) + pancardNum.substring(0, 5);
                console.log(accountNumber);
                return accountNumber;
            } else {
                return false;
            }
        } catch(err) {
            throw err;
        }
    }

    static async createAccount(customer_id, balance, account_type) {
        try {
            console.log("in createAccount");
            const pool = await poolPromise;
            const createAccountNumberResult = await this.createAccountNumber(customer_id);
            console.log(createAccountNumberResult);
            if (!createAccountNumberResult) {
                return false;
            } else {
                const sql = 'INSERT INTO Accounts (customer_id, balance, acc_status, account_type, account_number) VALUES (?, ?, ?, ?, ?)';
                const [res] = await pool.query(sql, [customer_id, balance, "Active", account_type, createAccountNumberResult]);
                console.log(res);
                return res;
            }
        } catch(err) {
            throw err;
        }
    }
}

export default Test;
